<?php

///////////
//
// PHP DYNAMIC DROP-DOWN BOX FOR ZABBIX PDF GENERATION
// THE IDEA BEHIND THIS IS TO CREATE A VERSION INDEPENDENT
// ADDON THAT CAN BE ADDED THROUGH SCREENS TO PREVENT BREAKAGE
//
///////////
//
// v0.1 - 1/14/12 - (c) Travis Mathis - travisdmathis@gmail.com
// Change Log: Added Form Selection, Data Gathering, Report Generation w/ basic time period selection
// pdfform.php(selection) / generatereport.php(report building) / pdf.php(report)i
// v0.2 - 2/7/12 
// Change Log: Removed mysql specific calls and replaced with API calls.  Moved config to central file
//
///////////

require_once("ZabbixAPI.class.php");
include("config.inc.php");

// ERROR REPORTING
error_reporting(E_ALL);
set_time_limit(1800);

// CONFIGURATION

function ReadArray($array) { global $hosts;
	include("config.inc.php");
	foreach($array as $key=>$value) {
		if(is_array($value)) {
			ReadArray($value);
		} else {
			if($key == 'host') {
				echo "<option value=\"$value\">$value</option>";
			} else {
			}
		}
	}
}

// ZabbixAPI Connection
ZabbixAPI::debugEnabled(TRUE);
ZabbixAPI::login($z_server,$z_user,$z_pass)
	or die('Unable to login: '.print_r(ZabbixAPI::getLastError(),true));
//fetch graph data host
$hosts = ZabbixAPI::fetch_array('host','get',array('extendoutput'=>'shorten','sortfield'=>'host','with_graphs'=>'1'))
	or die('Unable to get hosts: '.print_r(ZabbixAPI::getLastError(),true));

// FORM DROPDOWN BOXES W/ MYSQL QUERY DATA
echo "<center>";
echo "<form action='generatereport.php' method='GET'>";
echo "<b>SELECT SITE:</b> ";
echo "<select name=\"siteList\">\n";
echo "<option value=\"All\">All</option>\n";
ReadArray($hosts);
echo "</select>\n ";
echo "<b>TIME PERIOD:</b> ";
echo "<select name=\"timePeriod\">\n";
echo "<option value=\"Hour\">Hour</option>\n";
echo "<option value=\"Day\">Day</option>\n";
echo "<option value=\"Week\">Week</option>\n";
echo "<option value=\"Month\">Month</option>\n";
echo "<option value=\"Year\">Year</option>\n";
echo "</center>\n";
echo "</select>\n";
echo "</br></br>";

// dump data to data file


// SUBMIT
echo "<center><input type='submit' value='Generate'></center>";
echo "</form>";
?>
