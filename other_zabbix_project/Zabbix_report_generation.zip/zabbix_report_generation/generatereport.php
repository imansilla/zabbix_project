<?php
//////////
// 
// (c) Travis Mathis - travisdmathis@gmail.com
// Zabbix Report Generator v0.2 Beta
//
// INCLUDES
require_once("ZabbixAPI.class.php");
include("config.inc.php");
// ERROR REPORTING
error_reporting(E_ALL);
set_time_limit(1800);

// VARIABLES
$timeperiod  = $_GET['timePeriod'];
$site 		 = $_GET['siteList'];
$trimmedsite = str_replace(" ", "_",$site);

// FUNCTIONS
function GraphImageById ($graphid, $period = 3600, $width, $height) { global $z_server, $z_user, $z_pass, $z_tmp_cookies, $z_url_index, $z_url_graph, $z_url_api, $z_img_path, $z_login_data, $trimmedsite;
	include("config.inc.php");
	// file names
	$filename_cookie = $z_tmp_cookies ."zabbix_cookie_" .$graphid .".txt";
	$image_name = $z_img_path .$trimmedsite ."_" .$graphid .".png";

	//setup curl
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $z_url_index);
	curl_setopt($ch, CURLOPT_HEADER, false);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_BINARYTRANSFER, true);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $z_login_data);
	curl_setopt($ch, CURLOPT_COOKIEJAR, $filename_cookie);
	curl_setopt($ch, CURLOPT_COOKIEFILE, $filename_cookie);
	// login	
	curl_exec($ch);
	// get graph
	curl_setopt($ch, CURLOPT_URL, $z_url_graph ."?graphid=" .$graphid ."&width=" .$width ."&height=" .$height ."&period=" .$period);
	$output = curl_exec($ch);
	curl_close($ch);
	// delete cookie
	header("Content-type: image/png");
	unlink($filename_cookie);	
	$fp = fopen($image_name, 'w');
	fwrite($fp, $output);
	fclose($fp);
	header("Content-type: text/html");
}

function CreatePDF($array) { global $timeperiod, $data, $site, $trimmedsite, $z_img_path;
	include("config.inc.php");	
	foreach($array as $key=>$graphid) {
		if(is_array($graphid)) {
			CreatePDF($graphid);
		} else {
			if($key == 'graphid') {
				$file = "./data.txt";
				$image_name = $z_img_path .$trimmedsite ."_" .$graphid .".png";
				$fh = fopen($file, 'a') or die("can't open file");
				$stringData = "[" .$image_name ."]\n";
				fwrite($fh, $stringData);
				GraphImageById($graphid,$timeperiod,'750','150');
				fclose($fh);
			} else {
			}
		}
	}
}

function CreatePDFAll($array) { global $z_img_path, $timeperiod, $data, $site, $trimmedsite;
	include("config.inc.php");
	foreach($array as $key=>$graphid) {
		if(is_array($graphid)) {
		#	echo "$key: $graphid\n";
			CreatePDFAll($graphid);
		} else {
			if($key == 'graphid') {
				$file = "./data.txt";
				$image_name = $z_img_path .$trimmedsite ."_" .$graphid .".png";
				$fh = fopen($file, 'a') or die("can't open file");
				$stringData = "[" .$image_name ."]\n";
				fwrite($fh, $stringData);
				GraphImageById($graphid,$timeperiod,'750','150');
				fclose($fh);
			} else {
		}
		}
	}
}
	
// Header
echo "<b>Host: </b>" .$site ."</br>";
echo "<b>Time Period: </b>" .$timeperiod ."</br></br>";

// Format $timeperiod into seconds 
if($timeperiod == 'Hour'){
	$timeperiod = '3600';
} elseif($timeperiod == 'Day'){
	$timeperiod = '86400';
} elseif($timeperiod == 'Week'){
	$timeperiod = '604800';
} elseif($timeperiod == 'Month'){
	$timeperiod = '2678400';
} elseif($timeperiod == 'Year'){
	$timeperiod = '31536000';
}

// get graphids
// Login to Zabbix API using ZabbixAPI.class.php
ZabbixAPI::debugEnabled(TRUE);
ZabbixAPI::login($z_server,$z_user,$z_pass)
	or die('Unable to login: '.print_r(ZabbixAPI::getLastError(),true));
//fetch graph data host
$hostGraphs = ZabbixAPI::fetch_array('host','get',array('extendoutput'=>'shorten','select_graphs'=>'shorten','filter'=>array('host'=>$site)))
	or die('Unable to get graphs: '.print_r(ZabbixAPI::getLastError(),true));

$hostsGraphs = ZabbixAPI::fetch_array('host','get',array('extendoutput'=>'shorten','select_graphs'=>'shorten','filter'=>array('graphids'=>'')))
	or die('Unable to get graphs: '.print_r(ZabbixAPI::getLastError(),true));

#save graphs to directory for selected host
$data = "./data.txt";
$fh = fopen($data, 'w');
$stringData = "1<Introduction>\n";
fwrite($fh, $stringData);
$stringData = "This is an automatically generated PDF file containing data gathered from Zabbix Network Monitoring System.\n";
fwrite($fh, $stringData);
$stringData = "#NP\n";
fwrite($fh, $stringData);
$stringData = "2<Graphs>\n";
fwrite($fh, $stringData);
fclose($fh);

if($site == 'All') {
	CreatePDFAll($hostsGraphs);
} else {
	CreatePDF($hostGraphs);
}

header("Location: $pdf_location");

?>
