<?php
//CONFIGURABLE
# zabbix server info(user must have API access)
$z_server 	= 'http://url/to/zabbix/';
$z_user		= 'admin';
$z_pass		= 'password';
# tmp_images directory path
$z_img_path = '/path/to/tmp_images/';
# should be the tail of the URL
$pdf_location = $z_server ."url/to/pdf.php";
# paper settings
$paper_format = 'LETTER'; // formats supported: 4A0, 2A0, A0 -> A10, B0 -> B10, C0 -> C10, RA0 -> RA4, SRA0 -> SRA4, LETTER, LEGAL, EXECUTIVE, FOLIO
$paper_oreintation = 'portrait'; // formats supported: portrait / landscape
# time zone
$timezone = 'EST';

//DO NOT CHANGE BELOW THIS LINE
$z_tmp_cookies 	= "";
$z_url_index 	= $z_server ."index.php";
$z_url_graph	= $z_server ."chart2.php";
$z_url_api		= $z_server ."api_jsonrpc.php";
$z_login_data	= "name=" .$z_user ."&password=" .$z_pass ."&enter=Enter";
$data = './data.txt';
?>
